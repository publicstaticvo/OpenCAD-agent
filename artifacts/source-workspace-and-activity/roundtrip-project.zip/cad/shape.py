def dimensions(): return (40,30,15)
